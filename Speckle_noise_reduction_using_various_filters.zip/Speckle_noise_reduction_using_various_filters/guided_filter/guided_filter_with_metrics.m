function guided_filter_with_metrics()
    % Guided Filter with PSNR and RMSE Calculation for Speckle Noise

    clc; clear; close all;

    % Load an image
    image = imread('C:\Users\Dell\Desktop\Major_Project\h60.jpg'); % Replace with your image file
    if size(image, 3) == 3
        image = rgb2gray(image); % Convert to grayscale if it's a color image
    end

    % Normalize the image to range [0, 1]
    image = double(image) / 255;

    % Add speckle noise with variance 0.08
    noise_variance = 0.08;
    noisy_image = imnoise(image, 'speckle', noise_variance);

    % Parameters for the guided filter
    radius = 5;          % Radius of the window
    epsilon = 0.02;    % Regularization parameter

    % Apply guided filter
    filtered_image = guided_filter(noisy_image, noisy_image, radius, epsilon);

    % Calculate PSNR and RMSE
    psnr_value = calculate_psnr(image, filtered_image);
    rmse_value = calculate_rmse(image, filtered_image);

    % Display results
    figure;
    subplot(1, 2, 1); imshow(noisy_image, []); title(sprintf('Noisy Image\n(Speckle Variance: %.2f)', noise_variance));
    subplot(1, 2, 2); imshow(filtered_image, []);
    title(sprintf('Guided Filter\nPSNR: %.2f dB, RMSE: %.5f', psnr_value, rmse_value));
end

function guided_img = guided_filter(I, P, radius, epsilon)
    % I: Guidance image (input image)
    % P: Filtering image (input image)
    % radius: Window radius
    % epsilon: Regularization parameter

    [rows, cols] = size(I);
    N = box_filter(ones(rows, cols), radius);

    mean_I = box_filter(I, radius) ./ N;
    mean_P = box_filter(P, radius) ./ N;
    corr_I = box_filter(I .* I, radius) ./ N;
    corr_IP = box_filter(I .* P, radius) ./ N;

    var_I = corr_I - mean_I .* mean_I;
    cov_IP = corr_IP - mean_I .* mean_P;

    a = cov_IP ./ (var_I + epsilon);
    b = mean_P - a .* mean_I;

    mean_a = box_filter(a, radius) ./ N;
    mean_b = box_filter(b, radius) ./ N;

    guided_img = mean_a .* I + mean_b;
end

function result = box_filter(img, radius)
    % Fast box filter for mean calculation
    kernel = ones(2*radius + 1, 2*radius + 1);
    result = conv2(img, kernel, 'same');
end

function psnr_value = calculate_psnr(original, processed)
    % PSNR Calculation
    mse = mean((original(:) - processed(:)).^2);
    max_pixel_value = 1; % Since images are normalized to [0, 1]
    psnr_value = 10 * log10((max_pixel_value^2) / mse);
end

function rmse_value = calculate_rmse(original, processed)
    % RMSE Calculation
    mse = mean((original(:) - processed(:)).^2);
    rmse_value = sqrt(mse);
end
